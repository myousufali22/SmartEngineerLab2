let a=2; 
let b='2'; 
 console.log(a==b);//true
 console.log(a===b);//false
