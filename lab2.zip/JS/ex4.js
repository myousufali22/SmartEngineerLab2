let result;
result=Number('324');
console.log(result);

let res;
res=Number('hello');
console.log(res);

let output;
output=String(324);
console.log(output);

output=(324).toString();
console.log(output);

let out;
out=parseInt('20.01');
console.log(out);

out-parseFloat('20.01');
console.log(out);

out=Math.floor('20.01');
console.log(out);