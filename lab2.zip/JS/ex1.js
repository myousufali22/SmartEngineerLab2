var num=5;
let num2=10;
let x=5,y=6,z=7;
const a=5;
x=10;
let sum=44;
console.log(sum);